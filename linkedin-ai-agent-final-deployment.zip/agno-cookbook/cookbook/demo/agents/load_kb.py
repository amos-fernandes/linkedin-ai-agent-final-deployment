from agno_assist import agno_assist

if __name__ == "__main__":
    agno_assist.knowledge.load(recreate=True)
